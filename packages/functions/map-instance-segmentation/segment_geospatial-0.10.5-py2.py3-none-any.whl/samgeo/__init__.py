"""Top-level package for segment-geospatial."""

__author__ = """Qiusheng Wu"""
__email__ = "giswqs@gmail.com"
__version__ = "0.10.5"


from .samgeo import *
