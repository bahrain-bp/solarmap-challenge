DatasetID = str
VersionID = str
TaskType = str
ModelType = str
WorkspaceID = str
