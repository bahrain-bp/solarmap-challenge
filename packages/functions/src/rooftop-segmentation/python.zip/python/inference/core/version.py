__version__ = "0.10.0"


if __name__ == "__main__":
    print(__version__)
