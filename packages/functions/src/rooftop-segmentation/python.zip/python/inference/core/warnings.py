class InferenceDeprecationWarning(Warning):
    pass
