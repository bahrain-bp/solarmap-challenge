from inference.models.cogvlm.cogvlm import CogVLM
