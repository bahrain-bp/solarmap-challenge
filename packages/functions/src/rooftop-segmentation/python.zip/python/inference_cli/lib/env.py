import os

CLI_LOG_LEVEL = os.getenv("CLI_LOG_LEVEL", "INFO")
ROBOFLOW_API_KEY = os.getenv("ROBOFLOW_API_KEY")
